﻿using System;

namespace Practicum_21
{
    class Angle
    {
        public double degrees;
        public double minutes;
        public Angle()
        {
            degrees = 0;
            minutes = 0;
        }
      
        //копирующий конструктор
        public Angle(Angle copy)
        {
            degrees = copy.degrees;
            minutes = copy.minutes;
        }

        //метод перевода в радианны
        public void Radians()
        {
            double Rad = degrees * Math.PI / 180;
            double Rad2 = (minutes * 0.0166667) * Math.PI / 180;
            Console.WriteLine($"C градусов в радианы: {Math.Round(Rad, 3)}");
            Console.WriteLine($"С минут в градусы и в радианы: {Math.Round(Rad2, 3)} ");

            //сложение 
            void Summ()
            {
                Console.WriteLine();
                double summ = Rad + Rad2;
                Console.WriteLine($"Сумма = {Math.Round(summ, 3)}");
            }
            //вычитание
            void Razn()
            {
                if (Rad > Rad2)
                {
                    double raznost = Rad - Rad2;
                    Console.WriteLine($"Разность = {Math.Round(raznost,3)} ");
                }
                else
                {
                    double raznost = Rad2 - Rad;
                    Console.WriteLine($"Разность = {Math.Round(raznost,3)} ");
                }
            }
            Summ();
            Razn();
        }
        //вычисление синуса
        public void Sin ()
        {
            double sin = Math.Sin(degrees * Math.PI / 180);
            double sin_2 = Math.Sin((minutes * 0.0166667) * Math.PI / 180);
            Console.WriteLine($"sin = {Math.Round(sin,3)}  sin_2 = {Math.Round(sin_2,3)}");
        }
        //вычисление косинуса
        public void Cos ()
        {
            double cos = Math.Cos(degrees * Math.PI / 180);
            double cos_2 = Math.Cos((minutes * 0.0166667) * Math.PI / 180);
            Console.WriteLine($"cos = {Math.Round(cos,3)}  cos_2 = {Math.Round(cos_2,3)}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Angle angle = new Angle();
            Console.Write("Введите кол-во градусов(*)= ");
            angle.degrees = double.Parse(Console.ReadLine());

            Console.Write("Введите кол-во минут(`)= ");
            angle.minutes = double.Parse(Console.ReadLine());

            double minutes_2 = angle.degrees * 60;
            double degrees_2 = angle.minutes * 0.0166667;
            if (angle.degrees > degrees_2)
            {
                Console.WriteLine($"Градусы= От {Math.Round(degrees_2,3)}* до {Math.Round(angle.degrees,3)}*\nМинуты: От {Math.Round(angle.minutes,3)} до {Math.Round(minutes_2,3)}");
            }
            else
            {
                Console.WriteLine($"Градусы= От {Math.Round(angle.degrees,3)}* до {Math.Round(degrees_2,3)}*\nМинуты: От {Math.Round(minutes_2,3)} до {Math.Round(angle.minutes,3)}");
            }
            //метод с переводом в радианы и с вычислением суммы и разности
            angle.Radians();

            //метод вычисляющий синус
            angle.Sin();

            //метод вычисляющий косинус
            angle.Cos();

            //умножение
            double proizvedenie = angle.degrees * 10;
            double proizvedenie2 = degrees_2 * 12;
            //деление
            double chastnoe = angle.degrees / 14;
            double chastnoe2 = degrees_2 / 16;

            Console.WriteLine($"Произведение= " + "\n1:" + Math.Round(proizvedenie,3) + "\n2:" + Math.Round(proizvedenie2,3));

            Console.WriteLine("Частное= " + "\n1:" + Math.Round(chastnoe,3) + "\n2:" + Math.Round(chastnoe2,3));
            Console.ReadKey();
        }
    }
}
