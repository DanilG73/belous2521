﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Belous25._2
{
   

    class Program
    {
        static void Main(string[] args)
        {
            string inputFilePath = "input.txt";
            string outputFilePath = "output.txt";

            // Чтение первой и последней компоненты из файла
            double firstComponent = ReadFirstComponent(inputFilePath);
            double lastComponent = ReadLastComponent(inputFilePath);

            // Нахождение разности
            double difference = lastComponent - firstComponent;

            // Сохранение результата в новый файл
            SaveDifferenceToFile(difference, outputFilePath);

            Console.WriteLine($"Разность первой и последней компоненты файла: {difference}");
            Console.WriteLine($"Результат сохранен в файл: {outputFilePath}");
            Console.ReadKey();
        }

        static double ReadFirstComponent(string filePath)
        {
            // Чтение первой компоненты из файла
            string firstLine = File.ReadLines(filePath).First();
            return double.Parse(firstLine);
        }

        static double ReadLastComponent(string filePath)
        {
            // Чтение последней компоненты из файла
            string lastLine = File.ReadLines(filePath).Last();
            return double.Parse(lastLine);
        }

        static void SaveDifferenceToFile(double difference, string filePath)
        {
            // Сохранение разности в новый файл
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine($"Разность первой и последней компоненты файла: {difference}");
            }
        }
    }
}
