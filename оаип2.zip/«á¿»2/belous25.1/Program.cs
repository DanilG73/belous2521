﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

   namespace belous25._1
{
   

    class MilitaryPersonnel
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string Patronymic { get; set; }
        public string Address { get; set; }
        public string Nationality { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Position { get; set; }
        public string Rank { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Создаем список для хранения данных о военнослужащих
            List<MilitaryPersonnel> personnelList = new List<MilitaryPersonnel>();

            // Чтение данных из файла
            string filePath = "military_personnel.txt";
            ReadDataFromFile(filePath, personnelList);

            // Обработка данных и вывод информации о лейтенантах
            List<MilitaryPersonnel> lieutenants = GetLieutenants(personnelList);
            foreach (var lieutenant in lieutenants)
            {
                Console.WriteLine($"ФИО: {lieutenant.LastName} {lieutenant.FirstName} {lieutenant.Patronymic}");
                Console.WriteLine($"Дата рождения: {lieutenant.DateOfBirth.ToShortDateString()}");
                Console.WriteLine($"Адрес: {lieutenant.Address}");
                Console.WriteLine($"Национальность: {lieutenant.Nationality}");
                Console.WriteLine($"Должность: {lieutenant.Position}");
                Console.WriteLine($"Звание: {lieutenant.Rank}");
                Console.WriteLine();
            }

            // Сохранение результатов в новый файл
            string outputFilePath = "lieutenants.txt";
            SaveLieutenantsToFile(lieutenants, outputFilePath);

            Console.WriteLine("Данные о лейтенантах сохранены в файл: lieutenants.txt");
            Console.ReadKey();
        }

        static void ReadDataFromFile(string filePath, List<MilitaryPersonnel> personnelList)
        {
            // Проверка существования файла
            if (!File.Exists(filePath))
            {
                Console.WriteLine($"Файл {filePath} не найден.");
                return;
            }

            // Чтение данных из файла и добавление их в список
            string[] lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                string[] data = line.Split(';');
                if (data.Length == 9)
                {
                    MilitaryPersonnel personnel = new MilitaryPersonnel
                    {
                        LastName = data[0],
                        FirstName = data[1],
                        Patronymic = data[2],
                        Address = data[3],
                        Nationality = data[4],
                        DateOfBirth = DateTime.Parse(data[5]),
                        Position = data[6],
                        Rank = data[7]
                    };
                    personnelList.Add(personnel);
                }
            }
        }

        static List<MilitaryPersonnel> GetLieutenants(List<MilitaryPersonnel> personnelList)
        {
            // Фильтрация военнослужащих с званием "лейтенант"
            return personnelList.Where(person => person.Rank.ToLower() == "лейтенант").ToList();
        }

        static void SaveLieutenantsToFile(List<MilitaryPersonnel> lieutenants, string filePath)
        {
            // Запись информации о лейтенантах в новый файл
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var lieutenant in lieutenants)
                {
                    writer.WriteLine($"ФИО: {lieutenant.LastName} {lieutenant.FirstName} {lieutenant.Patronymic}");
                    writer.WriteLine($"Дата рождения: {lieutenant.DateOfBirth.ToShortDateString()}");
                    writer.WriteLine($"Адрес: {lieutenant.Address}");
                    writer.WriteLine($"Национальность: {lieutenant.Nationality}");
                    writer.WriteLine($"Должность: {lieutenant.Position}");
                    writer.WriteLine($"Звание: {lieutenant.Rank}");
                    writer.WriteLine();
                }
            }
        }
    }
}
