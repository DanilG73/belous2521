﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Belous25._3
{
    
    

    class Program
    {
        static void Main(string[] args)
        {
            string firstFilePath = "first_matrices.txt";
            string secondFilePath = "second_matrices.txt";

            // Поменять местами нечетные матрицы
            SwapOddMatrices(firstFilePath, secondFilePath);

            // Вывести содержимое файлов на экран
            Console.WriteLine("Содержимое первого файла:");
            Console.WriteLine(File.ReadAllText(firstFilePath));

            Console.WriteLine("\nСодержимое второго файла:");
            Console.WriteLine(File.ReadAllText(secondFilePath));
            Console.ReadKey();
        }

        static void SwapOddMatrices(string firstFilePath, string secondFilePath)
        {
            // Чтение матриц из файлов
            string[] firstMatrices = File.ReadAllLines(firstFilePath);
            string[] secondMatrices = File.ReadAllLines(secondFilePath);

            int minCount = Math.Min(firstMatrices.Length, secondMatrices.Length);

            // Поменять местами нечетные матрицы до конца меньшего из файлов
            for (int i = 0; i < minCount; i++)
            {
                if (i % 2 == 0)
                {
                    string temp = firstMatrices[i];
                    firstMatrices[i] = secondMatrices[i];
                    secondMatrices[i] = temp;
                }
            }

            // Записать обновленные матрицы в файлы
            File.WriteAllLines(firstFilePath, firstMatrices);
            File.WriteAllLines(secondFilePath, secondMatrices);
        }
    }
}
